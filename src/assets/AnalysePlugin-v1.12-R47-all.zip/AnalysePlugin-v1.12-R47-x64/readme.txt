Shorten your time of reading mega bytes of log files!                          DE 2019-01

Supporting Don HO's NotePad++ see https://notepad-plus-plus.org/

This sources are a dockable pattern search plugin for Notepad++ version 5.1 or later.
With this plugin you can search for multiple patterns in any of the opened documents 
in NotePad++. You may want to tune your search using all fancy tricks from NPP like
regular expressions or escaped patterns and give each of the searches different colors.
The result will be stored in a dockable window in same ordering as in the origin and
a double click allows you to jump to the original position. The tool follows the concept
of NPP using WinAPI pure only. It is designed to treat log-files of typical size like 60MB.

More features can be found in the help dialogue of the plugin.

For generating the dll file I use a  msdev compiler. If you like to port it to other OSs
just let me know your changes and I'll incorporate it.

The project site is:
https://sourceforge.net/p/analyseplugin/

Best Regards,
Mattes H. mattesh(at)gmx.net
